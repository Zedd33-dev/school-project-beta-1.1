const express = require("express");
const fs = require("fs");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const ARQ_PROFESSORES = "professores.json";
const ARQ_ALUNOS = "alunos.json";
const ARQ_OCORRENCIAS = "ocorrencias.json";

function lerArquivo(caminho, tipo = "obj") {
  if (!fs.existsSync(caminho)) return tipo === "array" ? [] : {};
  const dados = fs.readFileSync(caminho, "utf-8");
  try {
    return JSON.parse(dados);
  } catch {
    return tipo === "array" ? [] : {};
  }
}

function salvarArquivo(caminho, dados) {
  fs.writeFileSync(caminho, JSON.stringify(dados, null, 2));
}

// LOGIN PROFESSORES
app.post("/login", (req, res) => {
  const { usuario, senha } = req.body;
  const professores = lerArquivo(ARQ_PROFESSORES, "obj");
  if (professores[usuario] && professores[usuario].senha === senha) {
    res.json({ sucesso: true, nome: professores[usuario].nome });
  } else {
    res.status(401).json({ sucesso: false, mensagem: "Usuário ou senha inválidos." });
  }
});

// CADASTRAR OU DELETAR PROFESSOR
app.post("/professor", (req, res) => {
  const professores = lerArquivo(ARQ_PROFESSORES, "obj");

  if (req.body.deletar) {
    const usuario = req.body.nomeDeletar;
    if (!usuario || !professores[usuario]) {
      return res.status(404).json({ sucesso: false, mensagem: "Professor não encontrado." });
    }
    delete professores[usuario];
    salvarArquivo(ARQ_PROFESSORES, professores);
    return res.json({ sucesso: true });
  }

  const { nome, usuario, senha } = req.body;
  if (!nome || !usuario || !senha) return res.status(400).json({ sucesso: false, mensagem: "Preencha todos os campos." });
  if (professores[usuario]) return res.status(400).json({ sucesso: false, mensagem: "Usuário já existe." });

  professores[usuario] = { nome, senha };
  salvarArquivo(ARQ_PROFESSORES, professores);
  res.json({ sucesso: true });
});

// OBTER PROFESSORES
app.get("/professores", (req, res) => {
  const professores = lerArquivo(ARQ_PROFESSORES, "obj");
  res.json(professores);
});

// CADASTRAR OU DELETAR ALUNO
app.post("/aluno", (req, res) => {
  const alunos = lerArquivo(ARQ_ALUNOS, "obj");

  if (req.body.deletar) {
    const nome = req.body.nome;
    if (!nome || !alunos[nome]) {
      return res.status(404).json({ sucesso: false, mensagem: "Aluno não encontrado." });
    }
    delete alunos[nome];
    salvarArquivo(ARQ_ALUNOS, alunos);
    return res.json({ sucesso: true });
  }

  const { nome, ra } = req.body;
  if (!nome || !ra) return res.status(400).json({ sucesso: false, mensagem: "Nome e RA são obrigatórios." });

  // Verifica se RA já existe
  if (Object.values(alunos).includes(ra)) return res.status(400).json({ sucesso: false, mensagem: "RA já cadastrado." });

  alunos[nome] = ra;
  salvarArquivo(ARQ_ALUNOS, alunos);
  res.json({ sucesso: true });
});

// OBTER ALUNOS
app.get("/alunos", (req, res) => {
  const alunos = lerArquivo(ARQ_ALUNOS, "obj");
  res.json(alunos);
});

// CADASTRAR OCORRÊNCIA
app.post("/ocorrencia", (req, res) => {
  const nova = req.body;
  if (!nova || !nova.data || !nova.nomeAluno || !nova.raAluno) {
    return res.status(400).json({ sucesso: false, mensagem: "Campos obrigatórios faltando." });
  }
  let ocorrencias = lerArquivo(ARQ_OCORRENCIAS, "array");
  ocorrencias.push(nova);
  salvarArquivo(ARQ_OCORRENCIAS, ocorrencias);
  res.json({ sucesso: true });
});

// OBTER OCORRÊNCIAS
app.get("/ocorrencias", (req, res) => {
  const ocorrencias = lerArquivo(ARQ_OCORRENCIAS, "array");
  res.json(ocorrencias);
});

// DELETAR OCORRÊNCIA
app.delete("/ocorrencia/:index", (req, res) => {
  const idx = parseInt(req.params.index);
  let ocorrencias = lerArquivo(ARQ_OCORRENCIAS, "array");
  if (isNaN(idx) || idx < 0 || idx >= ocorrencias.length) {
    return res.status(404).json({ sucesso: false, mensagem: "Ocorrência não encontrada." });
  }
  ocorrencias.splice(idx, 1);
  salvarArquivo(ARQ_OCORRENCIAS, ocorrencias);
  res.json({ sucesso: true });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
